import { useState, useEffect } from 'react';
import { Heart, Eye, EyeOff, Lock } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import { usePrefs } from '@/contexts/PrefsContext';
import { useToast } from '@/components/Toast';
import { Spinner } from '@/components/Spinner';
import { t } from '@/lib/translations';

type AuthMode = 'login' | 'signup';

interface AuthScreenProps {
  defaultMode: AuthMode;
}

export function AuthScreen({ defaultMode }: AuthScreenProps) {
  const { signIn, signUp } = useAuth();
  const { language, theme, setLanguage, setTheme } = usePrefs();
  const { show } = useToast();

  const [mode, setMode] = useState<AuthMode>(defaultMode);
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const tr = (key: Parameters<typeof t>[1]) => t(language, key);

  useEffect(() => {
    setMode(defaultMode);
  }, [defaultMode]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (!username.trim()) {
      setError(tr('usernameRequired'));
      return;
    }
    if (!password) {
      setError(tr('passwordRequired'));
      return;
    }

    if (mode === 'signup') {
      if (password.length < 6) {
        setError(tr('passwordTooShort'));
        return;
      }
      if (password !== confirmPassword) {
        setError(tr('passwordsDontMatch'));
        return;
      }

      setLoading(true);
      const { error: signUpError } = await signUp(username, password);
      setLoading(false);

      if (signUpError) {
        setError(signUpError);
      } else {
        show(tr('loginSuccess'), 'success');
      }
    } else {
      setLoading(true);
      const { error: signInError } = await signIn(username, password);
      setLoading(false);

      if (signInError) {
        if (signInError.includes('Too many requests')) {
          setError(tr('tooManyAttempts'));
        } else {
          setError(tr('loginFailed'));
        }
      } else {
        show(tr('loginSuccess'), 'success');
      }
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-6 relative overflow-hidden
      bg-gradient-to-br from-rose-100 via-rose-50 to-amber-50
      dark:from-neutral-900 dark:via-neutral-900 dark:to-neutral-800">
      {/* Ambient blobs */}
      <div className="absolute top-[-10%] start-[-5%] w-72 h-72 rounded-full bg-rose-300/30 dark:bg-rose-500/10 blur-3xl animate-float" />
      <div className="absolute bottom-[-10%] end-[-5%] w-80 h-80 rounded-full bg-amber-300/25 dark:bg-amber-500/10 blur-3xl animate-float" style={{ animationDelay: '2s' }} />

      <div className="w-full max-w-sm relative z-10">
        {/* Logo */}
        <div className="flex flex-col items-center mb-8">
          <div className="relative w-20 h-20 rounded-3xl flex items-center justify-center
            bg-gradient-to-br from-rose-400 to-rose-500
            shadow-xl shadow-rose-500/30 mb-4 animate-liquid-pop">
            <div className="absolute inset-0 rounded-3xl bg-gradient-to-br from-white/40 to-transparent" />
            <Heart className="relative w-10 h-10 text-white drop-shadow" fill="white" />
          </div>
          <h1 className="text-3xl font-bold text-neutral-800 dark:text-neutral-50" dir="rtl">
            عشقولک
          </h1>
          <h2 className="text-lg font-medium text-neutral-500 dark:text-neutral-400 mt-1">
            Eshgholk
          </h2>
          <p className="text-sm text-neutral-500 dark:text-neutral-400 mt-3 text-center">
            {mode === 'login' ? tr('welcomeBack') : tr('setupTitle')}
          </p>
          <p className="text-xs text-neutral-400 dark:text-neutral-500 mt-1 text-center">
            {mode === 'login' ? tr('loginSubtitle') : tr('setupSubtitle')}
          </p>
        </div>

        {/* Glass card */}
        <div className="glass rounded-3.5xl p-6 space-y-5 animate-scale-in">
          {/* Mode toggle */}
          <div className="flex p-1 rounded-xl bg-neutral-100/60 dark:bg-neutral-800/60 backdrop-blur-sm">
            <button
              type="button"
              onClick={() => { setMode('login'); setError(''); }}
              className={`flex-1 py-2.5 rounded-lg text-sm font-medium transition-all duration-300
                ${mode === 'login'
                  ? 'glass-icon text-neutral-800 dark:text-white'
                  : 'text-neutral-500 dark:text-neutral-400'
                }`}
            >
              {tr('login')}
            </button>
            <button
              type="button"
              onClick={() => { setMode('signup'); setError(''); }}
              className={`flex-1 py-2.5 rounded-lg text-sm font-medium transition-all duration-300
                ${mode === 'signup'
                  ? 'glass-icon text-neutral-800 dark:text-white'
                  : 'text-neutral-500 dark:text-neutral-400'
                }`}
            >
              {tr('createAccount')}
            </button>
          </div>

          {/* Form */}
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-xs font-medium text-neutral-500 dark:text-neutral-400 mb-1.5">
                {tr('username')}
              </label>
              <input
                type="text"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                disabled={loading}
                autoComplete="username"
                className="glass-input w-full px-4 py-3 rounded-xl
                  text-neutral-800 dark:text-neutral-100
                  placeholder:text-neutral-400
                  focus:outline-none transition-all"
                placeholder={tr('username')}
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-neutral-500 dark:text-neutral-400 mb-1.5">
                {tr('password')}
              </label>
              <div className="relative">
                <input
                  type={showPassword ? 'text' : 'password'}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  disabled={loading}
                  autoComplete={mode === 'login' ? 'current-password' : 'new-password'}
                  className="glass-input w-full px-4 py-3 pr-11 rounded-xl
                    text-neutral-800 dark:text-neutral-100
                    placeholder:text-neutral-400
                    focus:outline-none transition-all"
                  placeholder={tr('password')}
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute end-3 top-1/2 -translate-y-1/2 text-neutral-400 hover:text-neutral-600 dark:hover:text-neutral-200 transition-colors"
                >
                  {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                </button>
              </div>
            </div>

            {mode === 'signup' && (
              <div className="animate-fade-in">
                <label className="block text-xs font-medium text-neutral-500 dark:text-neutral-400 mb-1.5">
                  {tr('confirmPassword')}
                </label>
                <div className="relative">
                  <input
                    type={showPassword ? 'text' : 'password'}
                    value={confirmPassword}
                    onChange={(e) => setConfirmPassword(e.target.value)}
                    disabled={loading}
                    autoComplete="new-password"
                    className="glass-input w-full px-4 py-3 pr-11 rounded-xl
                      text-neutral-800 dark:text-neutral-100
                      placeholder:text-neutral-400
                      focus:outline-none transition-all"
                    placeholder={tr('confirmPassword')}
                  />
                  <Lock className="absolute end-3 top-1/2 -translate-y-1/2 w-4 h-4 text-neutral-400" />
                </div>
              </div>
            )}

            {error && (
              <p className="text-sm text-rose-500 text-center animate-fade-in">{error}</p>
            )}

            <button
              type="submit"
              disabled={loading}
              className="btn-liquid w-full py-3.5 rounded-xl font-semibold text-white
                disabled:opacity-50 flex items-center justify-center gap-2"
            >
              {loading ? (
                <>
                  <Spinner className="w-5 h-5" />
                  {mode === 'login' ? tr('loggingIn') : tr('creatingAccount')}
                </>
              ) : (
                mode === 'login' ? tr('login') : tr('createAccount')
              )}
            </button>
          </form>

          {/* Switch link */}
          <p className="text-center text-sm text-neutral-500 dark:text-neutral-400">
            {mode === 'login' ? (
              <>
                {tr('dontHaveAccount')}{' '}
                <button
                  onClick={() => { setMode('signup'); setError(''); }}
                  className="font-semibold text-rose-500 hover:text-rose-600 transition-colors"
                >
                  {tr('signUpHere')}
                </button>
              </>
            ) : (
              <>
                {tr('alreadyHaveAccount')}{' '}
                <button
                  onClick={() => { setMode('login'); setError(''); }}
                  className="font-semibold text-rose-500 hover:text-rose-600 transition-colors"
                >
                  {tr('signInHere')}
                </button>
              </>
            )}
          </p>
        </div>

        {/* Controls */}
        <div className="flex items-center justify-center gap-4 mt-6">
          <button
            onClick={() => setLanguage(language === 'fa' ? 'en' : 'fa')}
            className="glass-icon text-xs font-medium text-neutral-500 dark:text-neutral-400
              hover:text-neutral-700 dark:hover:text-neutral-200 transition-colors px-3 py-1.5 rounded-lg"
          >
            {language === 'fa' ? 'English' : 'فارسی'}
          </button>
          <span className="w-px h-4 bg-neutral-300/50 dark:bg-neutral-600/50" />
          <button
            onClick={() => setTheme(theme === 'light' ? 'dark' : 'light')}
            className="glass-icon text-xs font-medium text-neutral-500 dark:text-neutral-400
              hover:text-neutral-700 dark:hover:text-neutral-200 transition-colors px-3 py-1.5 rounded-lg"
          >
            {theme === 'light' ? tr('dark') : tr('light')}
          </button>
        </div>
      </div>
    </div>
  );
}
