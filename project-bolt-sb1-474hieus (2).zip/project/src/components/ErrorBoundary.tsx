import { Component, type ReactNode } from 'react';
import { Heart } from 'lucide-react';

interface ErrorBoundaryProps {
  children: ReactNode;
}

interface ErrorBoundaryState {
  hasError: boolean;
}

export class ErrorBoundary extends Component<ErrorBoundaryProps, ErrorBoundaryState> {
  constructor(props: ErrorBoundaryProps) {
    super(props);
    this.state = { hasError: false };
  }

  static getDerivedStateFromError(): ErrorBoundaryState {
    return { hasError: true };
  }

  componentDidCatch(error: unknown): void {
    console.error('App error:', error);
  }

  handleRetry = () => {
    this.setState({ hasError: false });
  };

  render() {
    if (this.state.hasError) {
      return (
        <div className="flex min-h-screen flex-col items-center justify-center gap-5 bg-neutral-50 p-6 dark:bg-neutral-900">
          <div className="flex h-16 w-16 items-center justify-center rounded-2xl bg-rose-500 shadow-lg shadow-rose-500/20">
            <Heart className="h-8 w-8 text-white" fill="white" />
          </div>
          <div className="text-center">
            <h2 className="text-lg font-semibold text-neutral-800 dark:text-neutral-100">
              Something went wrong
            </h2>
            <p className="mt-1 text-sm text-neutral-500 dark:text-neutral-400">
              An unexpected error occurred. Please try again.
            </p>
          </div>
          <button
            onClick={this.handleRetry}
            className="rounded-xl bg-rose-500 px-6 py-3 text-sm font-semibold text-white shadow-lg shadow-rose-500/20 transition-all hover:bg-rose-600"
          >
            Retry
          </button>
        </div>
      );
    }

    return this.props.children;
  }
}
