import { useEffect, useState, useMemo, useCallback } from 'react';
import { Search, ArrowDownUp, Images, Plus, Heart } from 'lucide-react';
import { supabase, STORAGE_BUCKET } from '@/lib/supabase';
import { useAuth } from '@/contexts/AuthContext';
import { usePrefs } from '@/contexts/PrefsContext';
import { MemoryCard } from '@/components/MemoryCard';
import { Spinner } from '@/components/Spinner';
import type { Memory, SortOrder } from '@/types';
import { t } from '@/lib/translations';

interface MemoryGalleryProps {
  onMemoryClick: (memory: Memory, photoUrl: string) => void;
  onAddClick: () => void;
  refreshKey: number;
}

export function MemoryGallery({ onMemoryClick, onAddClick, refreshKey }: MemoryGalleryProps) {
  const { user } = useAuth();
  const { language } = usePrefs();
  const tr = (key: Parameters<typeof t>[1]) => t(language, key);

  const [memories, setMemories] = useState<Memory[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [search, setSearch] = useState('');
  const [sortOrder, setSortOrder] = useState<SortOrder>('newest');

  const loadMemories = useCallback(async () => {
    if (!user) return;
    setLoading(true);
    setError('');

    const { data, error: queryError } = await supabase
      .from('memories')
      .select('*')
      .order('memory_date', { ascending: sortOrder === 'oldest' });

    if (queryError) {
      setError(t(language, 'loadError'));
      setMemories([]);
    } else {
      const valid = (data ?? []).filter(
        (m) => m && typeof m.id === 'string' && typeof m.photo_path === 'string'
      ) as Memory[];
      setMemories(valid);
    }
    setLoading(false);
  }, [user, sortOrder, language]);

  useEffect(() => {
    loadMemories();
  }, [loadMemories, refreshKey]);

  const filtered = useMemo(() => {
    if (!search.trim()) return memories;
    const q = search.toLowerCase();
    return memories.filter(
      (m) =>
        m &&
        (m.title?.toLowerCase().includes(q) ||
          (m.description?.toLowerCase().includes(q) ?? false) ||
          (m.memory_date?.includes(q) ?? false))
    );
  }, [memories, search]);

  const getPhotoUrl = useCallback((path: string) => {
    return supabase.storage.from(STORAGE_BUCKET).getPublicUrl(path).data.publicUrl;
  }, []);

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20">
        <Spinner className="w-8 h-8 text-rose-400" />
      </div>
    );
  }

  if (error) {
    return (
      <div className="flex flex-col items-center justify-center py-20 gap-3">
        <p className="text-sm text-rose-500">{error}</p>
        <button
          onClick={loadMemories}
          className="text-sm text-rose-500 hover:underline"
        >
          {tr('loading')}
        </button>
      </div>
    );
  }

  return (
    <div className="space-y-5">
      {/* Gallery heading */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <div className="mb-2 flex items-center gap-2 text-rose-500">
            <Heart className="h-4 w-4" fill="currentColor" />
            <span className="text-xs font-semibold uppercase tracking-[0.18em]">Eshgholk</span>
          </div>
          <h1 className="text-2xl font-bold tracking-tight text-neutral-900 dark:text-white md:text-3xl">
            {tr('memories')}
          </h1>
          <p className="mt-1 text-sm text-neutral-500 dark:text-neutral-400">
            {memories.length === 0 ? tr('noMemoriesSubtitle') : `${memories.length} ${language === 'fa' ? 'خاطره' : 'memories'}`}
          </p>
        </div>
        <button
          onClick={onAddClick}
          className="btn-liquid hidden items-center justify-center gap-2 rounded-xl px-4 py-2.5 text-sm font-semibold text-white sm:flex"
        >
          <Plus className="h-4 w-4" strokeWidth={2.2} />
          {tr('addMemory')}
        </button>
      </div>

      {/* Search + Sort */}
      <div className="glass rounded-2xl p-3 sm:p-4">
        <div className="flex flex-col gap-3 sm:flex-row">
          <div className="relative flex-1">
            <Search className="absolute start-3 top-1/2 -translate-y-1/2 w-4 h-4 text-neutral-400" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder={tr('search')}
              className="glass-input w-full ps-10 pe-4 py-2.5 rounded-xl
                text-sm text-neutral-800 dark:text-neutral-100
                placeholder:text-neutral-400
                focus:outline-none transition-all"
            />
          </div>
          <div className="relative">
            <ArrowDownUp className="absolute start-3 top-1/2 -translate-y-1/2 w-4 h-4 text-neutral-400 pointer-events-none" />
            <select
              value={sortOrder}
              onChange={(e) => setSortOrder(e.target.value as SortOrder)}
              className="glass-input appearance-none ps-10 pe-8 py-2.5 rounded-xl
                text-sm text-neutral-800 dark:text-neutral-100
                focus:outline-none transition-all cursor-pointer"
            >
              <option value="newest">{tr('newest')}</option>
              <option value="oldest">{tr('oldest')}</option>
            </select>
          </div>
        </div>
      </div>

      {/* Gallery or Empty State */}
      {memories.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-20 px-6 text-center animate-fade-in">
          <div className="glass-icon w-20 h-20 rounded-full flex items-center justify-center mb-5">
            <Images className="w-10 h-10 text-rose-300 dark:text-rose-400/60" />
          </div>
          <h3 className="text-lg font-semibold text-neutral-700 dark:text-neutral-200 mb-1">
            {tr('noMemoriesTitle')}
          </h3>
          <p className="text-sm text-neutral-400 dark:text-neutral-500 mb-6">
            {tr('noMemoriesSubtitle')}
          </p>
          <button
            onClick={onAddClick}
            className="btn-liquid flex items-center gap-2 px-6 py-3 rounded-xl font-medium text-white"
          >
            <Plus className="w-5 h-5" strokeWidth={2.2} />
            {tr('addFirstMemory')}
          </button>
        </div>
      ) : filtered.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-20 text-center animate-fade-in">
          <p className="text-sm text-neutral-400 dark:text-neutral-500">{tr('noResults')}</p>
        </div>
      ) : (
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 sm:gap-4 lg:grid-cols-4">
          {filtered.map((memory) => (
            <MemoryCard
              key={memory.id}
              memory={memory}
              photoUrl={getPhotoUrl(memory.photo_path)}
              onClick={() => onMemoryClick(memory, getPhotoUrl(memory.photo_path))}
            />
          ))}
        </div>
      )}
    </div>
  );
}
