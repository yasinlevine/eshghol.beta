import { Heart, Images, Plus, Settings as SettingsIcon } from 'lucide-react';
import { usePrefs } from '@/contexts/PrefsContext';
import { t } from '@/lib/translations';

export type NavView = 'gallery' | 'add' | 'settings';

interface NavigationProps {
  current: NavView;
  onNavigate: (view: NavView) => void;
}

export function Navigation({ current, onNavigate }: NavigationProps) {
  const { language } = usePrefs();
  const tr = (key: Parameters<typeof t>[1]) => t(language, key);

  const items: { id: NavView; label: string; icon: typeof Images }[] = [
    { id: 'gallery', label: tr('memories'), icon: Images },
    { id: 'add', label: tr('add'), icon: Plus },
    { id: 'settings', label: tr('settings'), icon: SettingsIcon },
  ];

  return (
    <header className="sticky top-0 z-40 glass">
      <div className="mx-auto flex max-w-7xl items-center justify-between gap-4 px-4 py-3 md:px-8 md:py-4">
        {/* Logo */}
        <div className="flex shrink-0 items-center gap-3">
          <div className="relative flex h-11 w-11 items-center justify-center rounded-2.5xl
            bg-gradient-to-br from-rose-400 to-rose-500
            shadow-lg shadow-rose-500/30">
            <div className="absolute inset-0 rounded-2.5xl bg-gradient-to-br from-white/40 to-transparent" />
            <Heart className="relative h-5 w-5 text-white drop-shadow-sm" fill="white" />
          </div>
          <div className="hidden sm:block">
            <p className="text-base font-bold leading-tight text-neutral-900 dark:text-white">
              {tr('appName')}
            </p>
            <p className="text-[11px] text-neutral-400 dark:text-neutral-500">Eshgholk</p>
          </div>
        </div>

        {/* Nav items */}
        <nav className="flex min-w-0 items-center gap-1.5 overflow-x-auto scrollbar-hide" aria-label="Main navigation">
          {items.map((item) => {
            const Icon = item.icon;
            const active = current === item.id;
            const isAdd = item.id === 'add';
            return (
              <button
                key={item.id}
                onClick={() => onNavigate(item.id)}
                className={`flex min-h-10 shrink-0 items-center gap-2 rounded-xl px-3 text-sm font-medium transition-all duration-300 md:px-4
                  ${active && !isAdd
                    ? 'glass-icon text-rose-500 dark:text-rose-400'
                    : isAdd
                      ? 'btn-liquid text-white'
                      : 'text-neutral-500 hover:bg-neutral-100/60 hover:text-neutral-900 dark:text-neutral-400 dark:hover:bg-neutral-800/60 dark:hover:text-white'
                  }`}
              >
                <Icon className="h-4 w-4" strokeWidth={2.2} />
                <span>{item.label}</span>
              </button>
            );
          })}
        </nav>
      </div>
    </header>
  );
}
