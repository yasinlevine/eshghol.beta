import { useState } from 'react';
import { Sun, Moon, Languages, Lock, LogOut, KeyRound, Palette, Shield } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import { usePrefs } from '@/contexts/PrefsContext';
import { useToast } from '@/components/Toast';
import { Spinner } from '@/components/Spinner';
import { t } from '@/lib/translations';

interface SettingsProps {
  onLock: () => void;
}

export function Settings({ onLock }: SettingsProps) {
  const { user, signOut, changePassword } = useAuth();
  const { language, theme, setLanguage, setTheme } = usePrefs();
  const { show } = useToast();
  const tr = (key: Parameters<typeof t>[1]) => t(language, key);

  const [showChangePassword, setShowChangePassword] = useState(false);
  const [currentPw, setCurrentPw] = useState('');
  const [newPw, setNewPw] = useState('');
  const [confirmPw, setConfirmPw] = useState('');
  const [pwLoading, setPwLoading] = useState(false);
  const [pwError, setPwError] = useState('');

  const handleChangePassword = async (e: React.FormEvent) => {
    e.preventDefault();
    setPwError('');

    if (!currentPw || !newPw || !confirmPw) {
      setPwError(tr('passwordRequired'));
      return;
    }
    if (newPw.length < 6) {
      setPwError(tr('passwordTooShort'));
      return;
    }
    if (newPw !== confirmPw) {
      setPwError(tr('passwordsDontMatch'));
      return;
    }

    setPwLoading(true);
    const { error } = await changePassword(currentPw, newPw);
    setPwLoading(false);

    if (error) {
      if (error === 'current_password_wrong') {
        setPwError(tr('currentPasswordWrong'));
      } else {
        setPwError(tr('passwordChangeError'));
      }
    } else {
      show(tr('passwordChanged'), 'success');
      setShowChangePassword(false);
      setCurrentPw('');
      setNewPw('');
      setConfirmPw('');
    }
  };

  const handleLock = async () => {
    await onLock();
    show(tr('locked'), 'info');
  };

  const handleLogout = async () => {
    await signOut();
  };

  return (
    <div className="max-w-2xl mx-auto space-y-6 animate-fade-in">
      {/* Appearance */}
      <section className="glass rounded-3xl overflow-hidden">
        <div className="flex items-center gap-2.5 px-5 py-4 border-b border-white/10 dark:border-white/5">
          <div className="glass-icon flex h-7 w-7 items-center justify-center rounded-lg">
            <Palette className="w-3.5 h-3.5 text-rose-400" strokeWidth={2.2} />
          </div>
          <h3 className="font-semibold text-sm text-neutral-800 dark:text-neutral-100">
            {tr('appearance')}
          </h3>
        </div>
        <div className="p-3">
          <div className="grid grid-cols-2 gap-2">
            <button
              onClick={() => setTheme('light')}
              className={`flex items-center gap-2.5 px-4 py-3 rounded-xl transition-all duration-300
                ${theme === 'light'
                  ? 'glass-icon text-amber-600 dark:text-amber-400'
                  : 'text-neutral-500 dark:text-neutral-400 hover:bg-neutral-100/50 dark:hover:bg-neutral-700/50'
                }`}
            >
              <Sun className="w-5 h-5" strokeWidth={2.2} />
              <span className="font-medium text-sm">{tr('light')}</span>
            </button>
            <button
              onClick={() => setTheme('dark')}
              className={`flex items-center gap-2.5 px-4 py-3 rounded-xl transition-all duration-300
                ${theme === 'dark'
                  ? 'glass-icon text-blue-600 dark:text-blue-400'
                  : 'text-neutral-500 dark:text-neutral-400 hover:bg-neutral-100/50 dark:hover:bg-neutral-700/50'
                }`}
            >
              <Moon className="w-5 h-5" strokeWidth={2.2} />
              <span className="font-medium text-sm">{tr('dark')}</span>
            </button>
          </div>
        </div>
      </section>

      {/* Language */}
      <section className="glass rounded-3xl overflow-hidden">
        <div className="flex items-center gap-2.5 px-5 py-4 border-b border-white/10 dark:border-white/5">
          <div className="glass-icon flex h-7 w-7 items-center justify-center rounded-lg">
            <Languages className="w-3.5 h-3.5 text-rose-400" strokeWidth={2.2} />
          </div>
          <h3 className="font-semibold text-sm text-neutral-800 dark:text-neutral-100">
            {tr('language')}
          </h3>
        </div>
        <div className="p-3">
          <div className="grid grid-cols-2 gap-2">
            <button
              onClick={() => setLanguage('fa')}
              className={`px-4 py-3 rounded-xl font-medium text-sm transition-all duration-300
                ${language === 'fa'
                  ? 'glass-icon text-rose-500 dark:text-rose-400'
                  : 'text-neutral-500 dark:text-neutral-400 hover:bg-neutral-100/50 dark:hover:bg-neutral-700/50'
                }`}
            >
              فارسی
            </button>
            <button
              onClick={() => setLanguage('en')}
              className={`px-4 py-3 rounded-xl font-medium text-sm transition-all duration-300
                ${language === 'en'
                  ? 'glass-icon text-rose-500 dark:text-rose-400'
                  : 'text-neutral-500 dark:text-neutral-400 hover:bg-neutral-100/50 dark:hover:bg-neutral-700/50'
                }`}
            >
              English
            </button>
          </div>
        </div>
      </section>

      {/* Security */}
      <section className="glass rounded-3xl overflow-hidden">
        <div className="flex items-center gap-2.5 px-5 py-4 border-b border-white/10 dark:border-white/5">
          <div className="glass-icon flex h-7 w-7 items-center justify-center rounded-lg">
            <Shield className="w-3.5 h-3.5 text-rose-400" strokeWidth={2.2} />
          </div>
          <h3 className="font-semibold text-sm text-neutral-800 dark:text-neutral-100">
            {tr('security')}
          </h3>
        </div>
        <div className="p-3 space-y-1">
          <button
            onClick={() => setShowChangePassword(!showChangePassword)}
            className="w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all
              text-neutral-600 dark:text-neutral-300
              hover:bg-neutral-100/50 dark:hover:bg-neutral-700/50"
          >
            <KeyRound className="w-5 h-5 text-neutral-400" strokeWidth={2.2} />
            <span className="font-medium text-sm flex-1 text-start">{tr('changePassword')}</span>
          </button>

          {showChangePassword && (
            <form onSubmit={handleChangePassword} className="px-4 py-3 space-y-3 animate-fade-in">
              <input
                type="password"
                value={currentPw}
                onChange={(e) => setCurrentPw(e.target.value)}
                disabled={pwLoading}
                placeholder={tr('currentPassword')}
                autoComplete="current-password"
                className="glass-input w-full px-3 py-2.5 rounded-lg
                  text-sm text-neutral-800 dark:text-neutral-100
                  placeholder:text-neutral-400
                  focus:outline-none transition-all"
              />
              <input
                type="password"
                value={newPw}
                onChange={(e) => setNewPw(e.target.value)}
                disabled={pwLoading}
                placeholder={tr('newPassword')}
                autoComplete="new-password"
                className="glass-input w-full px-3 py-2.5 rounded-lg
                  text-sm text-neutral-800 dark:text-neutral-100
                  placeholder:text-neutral-400
                  focus:outline-none transition-all"
              />
              <input
                type="password"
                value={confirmPw}
                onChange={(e) => setConfirmPw(e.target.value)}
                disabled={pwLoading}
                placeholder={tr('confirmNewPassword')}
                autoComplete="new-password"
                className="glass-input w-full px-3 py-2.5 rounded-lg
                  text-sm text-neutral-800 dark:text-neutral-100
                  placeholder:text-neutral-400
                  focus:outline-none transition-all"
              />
              {pwError && <p className="text-xs text-rose-500">{pwError}</p>}
              <button
                type="submit"
                disabled={pwLoading}
                className="btn-liquid w-full py-2.5 rounded-lg font-medium text-white
                  disabled:opacity-50 flex items-center justify-center gap-2"
              >
                {pwLoading ? <Spinner className="w-4 h-4" /> : tr('save')}
              </button>
            </form>
          )}

          <button
            onClick={handleLock}
            className="w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all
              text-neutral-600 dark:text-neutral-300
              hover:bg-neutral-100/50 dark:hover:bg-neutral-700/50"
          >
            <Lock className="w-5 h-5 text-neutral-400" strokeWidth={2.2} />
            <span className="font-medium text-sm flex-1 text-start">{tr('lockNow')}</span>
          </button>

          <button
            onClick={handleLogout}
            className="w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all
              text-rose-500 hover:bg-rose-50/50 dark:hover:bg-rose-500/10"
          >
            <LogOut className="w-5 h-5" strokeWidth={2.2} />
            <span className="font-medium text-sm flex-1 text-start">{tr('logout')}</span>
          </button>
        </div>
      </section>

      {/* Account info */}
      {user && (
        <p className="text-center text-xs text-neutral-400 dark:text-neutral-500 pb-2">
          @{user.email?.replace('@eshgholk.app', '')}
        </p>
      )}
    </div>
  );
}
