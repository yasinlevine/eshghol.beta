import { Loader2 } from 'lucide-react';

export function Spinner({ className = 'w-5 h-5' }: { className?: string }) {
  return <Loader2 className={`${className} animate-spin`} />;
}

export function FullScreenSpinner({ label }: { label?: string }) {
  return (
    <div className="min-h-screen flex flex-col items-center justify-center gap-3
      bg-neutral-50 dark:bg-neutral-900">
      <Spinner className="w-8 h-8 text-rose-400" />
      {label && (
        <p className="text-sm text-neutral-500 dark:text-neutral-400">{label}</p>
      )}
    </div>
  );
}
