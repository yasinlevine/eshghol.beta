import { Calendar } from 'lucide-react';
import type { Memory } from '@/types';
import { usePrefs } from '@/contexts/PrefsContext';
import { formatDateShort } from '@/lib/date';

interface MemoryCardProps {
  memory: Memory;
  photoUrl: string;
  onClick: () => void;
}

export function MemoryCard({ memory, photoUrl, onClick }: MemoryCardProps) {
  const { language } = usePrefs();

  const title = memory?.title ?? '';
  const dateStr = memory?.memory_date ?? null;

  return (
    <button
      onClick={onClick}
      className="group relative overflow-hidden rounded-3xl glass
        hover:shadow-xl transition-all duration-500
        text-start w-full animate-slide-up"
    >
      <div className="aspect-square overflow-hidden rounded-t-3xl bg-neutral-100/50 dark:bg-neutral-700/50 relative">
        {photoUrl ? (
          <img
            src={photoUrl}
            alt={title}
            loading="lazy"
            onError={(e) => {
              (e.currentTarget as HTMLImageElement).style.display = 'none';
            }}
            className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
          />
        ) : (
          <div className="flex h-full w-full items-center justify-center text-neutral-300 dark:text-neutral-600">
            <Calendar className="h-8 w-8" />
          </div>
        )}
        {/* Glass overlay on hover */}
        <div className="absolute inset-0 bg-gradient-to-t from-black/20 via-transparent to-transparent
          opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
      </div>

      <div className="p-3.5 space-y-1">
        <h3 className="font-semibold text-sm text-neutral-800 dark:text-neutral-100
          line-clamp-1 leading-tight">
          {title || '—'}
        </h3>
        <div className="flex items-center gap-1.5 text-xs text-neutral-400 dark:text-neutral-500">
          <Calendar className="w-3 h-3" strokeWidth={2.2} />
          <span>{formatDateShort(dateStr, language)}</span>
        </div>
      </div>
    </button>
  );
}
