import { useState, useRef, useCallback, useEffect } from 'react';
import { X, ImagePlus, Calendar } from 'lucide-react';
import { supabase, STORAGE_BUCKET } from '@/lib/supabase';
import { useAuth } from '@/contexts/AuthContext';
import { usePrefs } from '@/contexts/PrefsContext';
import { useToast } from '@/components/Toast';
import { Spinner } from '@/components/Spinner';
import { DatePicker } from '@/components/DatePicker';
import type { Memory } from '@/types';
import { t } from '@/lib/translations';
import { todayISO } from '@/lib/date';

interface MemoryFormProps {
  open: boolean;
  editingMemory?: Memory | null;
  existingPhotoUrl?: string;
  onClose: () => void;
  onSaved: () => void;
}

const MAX_FILE_SIZE = 10 * 1024 * 1024;
const ALLOWED_TYPES = ['image/jpeg', 'image/jpg', 'image/png', 'image/webp'];

export function MemoryForm({ open, editingMemory, existingPhotoUrl, onClose, onSaved }: MemoryFormProps) {
  const { user } = useAuth();
  const { language } = usePrefs();
  const { show } = useToast();
  const tr = (key: Parameters<typeof t>[1]) => t(language, key);

  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [date, setDate] = useState(todayISO());
  const [photoFile, setPhotoFile] = useState<File | null>(null);
  const [photoPreview, setPhotoPreview] = useState<string>('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const fileInputRef = useRef<HTMLInputElement>(null);

  const isEditing = !!editingMemory;

  useEffect(() => {
    if (open) {
      if (editingMemory) {
        setTitle(editingMemory.title);
        setDescription(editingMemory.description ?? '');
        setDate(editingMemory.memory_date);
        setPhotoPreview(existingPhotoUrl ?? '');
      } else {
        setTitle('');
        setDescription('');
        setDate(todayISO());
        setPhotoPreview('');
      }
      setPhotoFile(null);
      setError('');
    }
  }, [open, editingMemory, existingPhotoUrl]);

  const handleFileSelect = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!ALLOWED_TYPES.includes(file.type)) {
      setError(tr('invalidFileType'));
      return;
    }
    if (file.size > MAX_FILE_SIZE) {
      setError(tr('fileTooLarge'));
      return;
    }

    setError('');
    setPhotoFile(file);
    setPhotoPreview(URL.createObjectURL(file));
  }, [tr]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (!title.trim()) {
      setError(tr('titleRequired'));
      return;
    }
    if (!date) {
      setError(tr('dateRequired'));
      return;
    }
    if (!isEditing && !photoFile) {
      setError(tr('photoRequired'));
      return;
    }

    setLoading(true);

    try {
      let photoPath = editingMemory?.photo_path ?? '';

      if (photoFile) {
        const fileExt = photoFile.name.split('.').pop();
        const fileName = `${user?.id}/${Date.now()}.${fileExt}`;
        const { error: uploadError } = await supabase.storage
          .from(STORAGE_BUCKET)
          .upload(fileName, photoFile);

        if (uploadError) throw new Error(tr('uploadError'));

        if (isEditing && editingMemory?.photo_path) {
          await supabase.storage.from(STORAGE_BUCKET).remove([editingMemory.photo_path]);
        }

        photoPath = fileName;
      }

      if (isEditing && editingMemory) {
        const { error: updateError } = await supabase
          .from('memories')
          .update({
            title: title.trim(),
            description: description.trim() || null,
            memory_date: date,
            photo_path: photoPath,
          })
          .eq('id', editingMemory.id);

        if (updateError) throw new Error(tr('saveError'));
        show(tr('changesSaved'), 'success');
      } else {
        const { error: insertError } = await supabase
          .from('memories')
          .insert({
            title: title.trim(),
            description: description.trim() || null,
            memory_date: date,
            photo_path: photoPath,
          });

        if (insertError) throw new Error(tr('saveError'));
        show(tr('memorySaved'), 'success');
      }

      onSaved();
    } catch (err) {
      const message = err instanceof Error ? err.message : tr('saveError');
      setError(message);
    } finally {
      setLoading(false);
    }
  };

  if (!open) return null;

  return (
    <div
      className="fixed inset-0 z-[80] flex items-center justify-center p-0 sm:p-6
        bg-black/40 backdrop-blur-md animate-fade-in"
      onClick={onClose}
    >
      <div
        className="glass-heavy w-full h-full sm:h-auto sm:max-w-lg
          sm:max-h-[90vh] sm:rounded-3.5xl overflow-hidden
          flex flex-col animate-scale-in"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between p-4 shrink-0">
          <h2 className="text-lg font-semibold text-neutral-800 dark:text-neutral-100">
            {isEditing ? tr('editMemory') : tr('addMemory')}
          </h2>
          <button
            onClick={onClose}
            className="glass-icon w-9 h-9 rounded-full flex items-center justify-center
              text-neutral-500 dark:text-neutral-300
              hover:text-neutral-700 dark:hover:text-neutral-100 transition-colors shrink-0"
          >
            <X className="w-5 h-5" strokeWidth={2.2} />
          </button>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="overflow-y-auto flex-1 scrollbar-hide">
          <div className="p-5 space-y-5">
            {/* Photo */}
            <div>
              <label className="block text-xs font-medium text-neutral-500 dark:text-neutral-400 mb-2">
                {tr('memoryPhoto')} <span className="text-rose-400">*</span>
              </label>
              <input
                ref={fileInputRef}
                type="file"
                accept="image/jpeg,image/png,image/webp"
                onChange={handleFileSelect}
                disabled={loading}
                className="hidden"
              />
              {photoPreview ? (
                <div className="relative group">
                  <img
                    src={photoPreview}
                    alt="Preview"
                    className="w-full max-h-64 object-cover rounded-2xl border border-white/20 dark:border-white/10"
                  />
                  <button
                    type="button"
                    onClick={() => fileInputRef.current?.click()}
                    disabled={loading}
                    className="glass absolute bottom-2 end-2 px-3 py-1.5 rounded-lg text-xs font-medium
                      text-neutral-700 dark:text-neutral-200 hover:shadow-md transition-all"
                  >
                    {tr('changePhoto')}
                  </button>
                </div>
              ) : (
                <button
                  type="button"
                  onClick={() => fileInputRef.current?.click()}
                  disabled={loading}
                  className="glass w-full py-12 rounded-2xl
                    hover:shadow-md text-neutral-400 dark:text-neutral-500
                    hover:text-rose-400 transition-all duration-300
                    flex flex-col items-center gap-2"
                >
                  <ImagePlus className="w-8 h-8" strokeWidth={1.8} />
                  <span className="text-sm font-medium">{tr('selectPhoto')}</span>
                </button>
              )}
            </div>

            {/* Title */}
            <div>
              <label className="block text-xs font-medium text-neutral-500 dark:text-neutral-400 mb-1.5">
                {tr('memoryTitle')} <span className="text-rose-400">*</span>
              </label>
              <input
                type="text"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                disabled={loading}
                className="glass-input w-full px-4 py-3 rounded-xl
                  text-neutral-800 dark:text-neutral-100
                  placeholder:text-neutral-400
                  focus:outline-none transition-all"
                placeholder={tr('memoryTitle')}
              />
            </div>

            {/* Date */}
            <div>
              <label className="block text-xs font-medium text-neutral-500 dark:text-neutral-400 mb-1.5">
                {tr('memoryDate')} <span className="text-rose-400">*</span>
              </label>
              <div className="relative">
                <Calendar className="absolute start-3 top-1/2 -translate-y-1/2 w-4 h-4 text-neutral-400 pointer-events-none z-10" />
                <DatePicker
                  value={date}
                  onChange={setDate}
                  disabled={loading}
                />
              </div>
            </div>

            {/* Description */}
            <div>
              <div className="flex items-center justify-between mb-1.5">
                <label className="block text-xs font-medium text-neutral-500 dark:text-neutral-400">
                  {tr('memoryDescription')}{' '}
                  <span className="text-neutral-400 dark:text-neutral-500">({tr('optional')})</span>
                </label>
                <span className={`text-xs ${description.length > 500 ? 'text-rose-500' : 'text-neutral-400'}`}>
                  {description.length} / 500
                </span>
              </div>
              <textarea
                value={description}
                onChange={(e) => setDescription(e.target.value.slice(0, 500))}
                disabled={loading}
                rows={4}
                maxLength={500}
                className="glass-input w-full px-4 py-3 rounded-xl
                  text-neutral-800 dark:text-neutral-100
                  placeholder:text-neutral-400
                  focus:outline-none transition-all resize-none"
                placeholder={tr('memoryDescription')}
              />
            </div>

            {error && (
              <p className="text-sm text-rose-500 text-center animate-fade-in">{error}</p>
            )}
          </div>

          {/* Footer */}
          <div className="flex gap-3 p-4 sticky bottom-0 glass">
            <button
              type="button"
              onClick={onClose}
              disabled={loading}
              className="glass flex-1 py-3 rounded-xl font-medium text-neutral-700 dark:text-neutral-200
                hover:shadow-md transition-all disabled:opacity-50"
            >
              {tr('cancel')}
            </button>
            <button
              type="submit"
              disabled={loading}
              className="btn-liquid flex-1 py-3 rounded-xl font-medium text-white
                disabled:opacity-50 flex items-center justify-center gap-2"
            >
              {loading ? (
                <>
                  <Spinner className="w-5 h-5" />
                  {tr('saving')}
                </>
              ) : (
                tr('save')
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
