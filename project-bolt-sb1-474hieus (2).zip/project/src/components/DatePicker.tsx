import { useState, useMemo } from 'react';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import {
  JALALI_MONTHS, JALALI_WEEKDAYS_SHORT, GREGORIAN_MONTHS, GREGORIAN_WEEKDAYS_SHORT,
  isoToJalali, jalaliToISO, jalaliDaysInMonth, gregorianDaysInMonth,
  getJalaliMonthFirstWeekday, toPersianDigits,
} from '@/lib/date';
import { usePrefs } from '@/contexts/PrefsContext';
import { t } from '@/lib/translations';

interface DatePickerProps {
  value: string;
  onChange: (iso: string) => void;
  disabled?: boolean;
}

export function DatePicker({ value, onChange, disabled }: DatePickerProps) {
  const { language } = usePrefs();
  const isFa = language === 'fa';

  const initial = useMemo(() => {
    if (!value) {
      const today = new Date();
      return isoToJalali(`${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, '0')}-${String(today.getDate()).padStart(2, '0')}`);
    }
    return isoToJalali(value);
  }, [value]);

  const [viewYear, setViewYear] = useState(initial.jy);
  const [viewMonth, setViewMonth] = useState(initial.jm);
  const [open, setOpen] = useState(false);

  const selected = value ? isoToJalali(value) : null;

  const monthNames = isFa ? JALALI_MONTHS : GREGORIAN_MONTHS;
  const weekdayNames = isFa ? JALALI_WEEKDAYS_SHORT : GREGORIAN_WEEKDAYS_SHORT;
  const currentYear = isFa ? viewYear : viewYear + 621;
  const currentMonth = isFa ? viewMonth : ((viewMonth + 2) % 12) + 1;

  const daysInMonth = isFa
    ? jalaliDaysInMonth(viewYear, viewMonth)
    : gregorianDaysInMonth(currentYear, currentMonth);

  const firstWeekday = isFa
    ? getJalaliMonthFirstWeekday(viewYear, viewMonth)
    : new Date(currentYear, currentMonth - 1, 1).getDay();

  const handlePrevMonth = () => {
    if (viewMonth === 1) {
      setViewMonth(12);
      setViewYear((y) => y - 1);
    } else {
      setViewMonth((m) => m - 1);
    }
  };

  const handleNextMonth = () => {
    if (viewMonth === 12) {
      setViewMonth(1);
      setViewYear((y) => y + 1);
    } else {
      setViewMonth((m) => m + 1);
    }
  };

  const handleDayClick = (day: number) => {
    const iso = isFa
      ? jalaliToISO(viewYear, viewMonth, day)
      : `${currentYear}-${String(currentMonth).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
    onChange(iso);
    setOpen(false);
  };

  const displayValue = selected
    ? isFa
      ? `${toPersianDigits(selected.jy)} ${JALALI_MONTHS[selected.jm - 1]} ${toPersianDigits(selected.jd)}`
      : `${GREGORIAN_MONTHS[selected.jm - 1]} ${selected.jd}, ${selected.jy}`
    : '';

  const cells: (number | null)[] = [];
  for (let i = 0; i < firstWeekday; i++) cells.push(null);
  for (let d = 1; d <= daysInMonth; d++) cells.push(d);

  const headerLabel = isFa
    ? `${JALALI_MONTHS[viewMonth - 1]} ${toPersianDigits(viewYear)}`
    : `${GREGORIAN_MONTHS[currentMonth - 1]} ${currentYear}`;

  return (
    <div className="relative">
      <button
        type="button"
        onClick={() => !disabled && setOpen(!open)}
        disabled={disabled}
        className="glass-input w-full ps-10 pe-4 py-3 rounded-xl
          text-neutral-800 dark:text-neutral-100
          focus:outline-none transition-all text-start text-sm disabled:opacity-50"
      >
        {displayValue || (isFa ? 'انتخاب تاریخ' : 'Select date')}
      </button>

      {open && (
        <>
          <div
            className="fixed inset-0 z-[85]"
            onClick={() => setOpen(false)}
          />
          <div className="glass-heavy absolute z-[86] mt-2 p-4 rounded-2xl
            w-[280px] animate-scale-in"
            dir={isFa ? 'rtl' : 'ltr'}
          >
            {/* Month navigation */}
            <div className="flex items-center justify-between mb-3">
              <button
                type="button"
                onClick={handlePrevMonth}
                className="glass-icon w-8 h-8 rounded-lg flex items-center justify-center
                  text-neutral-500 dark:text-neutral-300 hover:text-neutral-700 dark:hover:text-neutral-100 transition-colors"
              >
                {isFa ? <ChevronRight className="w-4 h-4" strokeWidth={2.2} /> : <ChevronLeft className="w-4 h-4" strokeWidth={2.2} />}
              </button>
              <span className="text-sm font-semibold text-neutral-800 dark:text-neutral-100">
                {headerLabel}
              </span>
              <button
                type="button"
                onClick={handleNextMonth}
                className="glass-icon w-8 h-8 rounded-lg flex items-center justify-center
                  text-neutral-500 dark:text-neutral-300 hover:text-neutral-700 dark:hover:text-neutral-100 transition-colors"
              >
                {isFa ? <ChevronLeft className="w-4 h-4" strokeWidth={2.2} /> : <ChevronRight className="w-4 h-4" strokeWidth={2.2} />}
              </button>
            </div>

            {/* Weekday headers */}
            <div className="grid grid-cols-7 gap-1 mb-1">
              {weekdayNames.map((d) => (
                <div key={d} className="text-center text-[11px] font-medium text-neutral-400 py-1">
                  {d}
                </div>
              ))}
            </div>

            {/* Days grid */}
            <div className="grid grid-cols-7 gap-1">
              {cells.map((day, i) => {
                if (day === null) {
                  return <div key={i} />;
                }
                const isSelected = selected && selected.jy === viewYear && selected.jm === viewMonth && selected.jd === day;
                return (
                  <button
                    key={i}
                    type="button"
                    onClick={() => handleDayClick(day)}
                    className={`h-9 rounded-lg text-sm font-medium transition-all duration-200
                      ${isSelected
                        ? 'btn-liquid text-white'
                        : 'text-neutral-700 dark:text-neutral-200 hover:bg-neutral-100/60 dark:hover:bg-neutral-700/60'
                      }`}
                  >
                    {isFa ? toPersianDigits(day) : day}
                  </button>
                );
              })}
            </div>
          </div>
        </>
      )}
    </div>
  );
}
