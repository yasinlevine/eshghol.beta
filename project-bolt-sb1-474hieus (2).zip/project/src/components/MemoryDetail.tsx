import { X, Pencil, Trash2 } from 'lucide-react';
import type { Memory } from '@/types';
import { usePrefs } from '@/contexts/PrefsContext';
import { formatDate } from '@/lib/date';
import { t } from '@/lib/translations';

interface MemoryDetailProps {
  memory: Memory;
  photoUrl: string;
  onClose: () => void;
  onEdit: () => void;
  onDelete: () => void;
}

export function MemoryDetail({ memory, photoUrl, onClose, onEdit, onDelete }: MemoryDetailProps) {
  const { language } = usePrefs();
  const tr = (key: Parameters<typeof t>[1]) => t(language, key);

  return (
    <div
      className="fixed inset-0 z-[80] flex items-center justify-center p-0 sm:p-6
      bg-black/40 backdrop-blur-md animate-fade-in"
      onClick={onClose}
    >
      <div
        className="glass-heavy w-full h-full sm:h-auto sm:max-w-2xl
          sm:max-h-[90vh] sm:rounded-3.5xl overflow-hidden
          flex flex-col animate-scale-in"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between p-4 shrink-0">
          <h2 className="text-lg font-semibold text-neutral-800 dark:text-neutral-100 line-clamp-1">
            {memory.title}
          </h2>
          <button
            onClick={onClose}
            className="glass-icon w-9 h-9 rounded-full flex items-center justify-center
              text-neutral-500 dark:text-neutral-300
              hover:text-neutral-700 dark:hover:text-neutral-100 transition-colors shrink-0"
          >
            <X className="w-5 h-5" strokeWidth={2.2} />
          </button>
        </div>

        {/* Scrollable content */}
        <div className="overflow-y-auto flex-1 scrollbar-hide">
          {/* Photo */}
          <div className="w-full bg-neutral-100/50 dark:bg-neutral-800/50">
            <img
              src={photoUrl}
              alt={memory.title}
              className="w-full max-h-[50vh] object-contain"
            />
          </div>

          {/* Details */}
          <div className="p-5 space-y-4">
            <div>
              <p className="text-xs font-medium text-neutral-400 dark:text-neutral-500 mb-1">
                {tr('memoryDate')}
              </p>
              <p className="text-sm text-neutral-700 dark:text-neutral-200">
                {formatDate(memory.memory_date, language)}
              </p>
            </div>

            {memory.description && (
              <div>
                <p className="text-xs font-medium text-neutral-400 dark:text-neutral-500 mb-1">
                  {tr('memoryDescription')}
                </p>
                <p className="text-sm text-neutral-700 dark:text-neutral-200 leading-relaxed whitespace-pre-wrap">
                  {memory.description}
                </p>
              </div>
            )}
          </div>
        </div>

      </div>

      {/* Floating action buttons */}
      <button
        onClick={onEdit}
        aria-label={tr('edit')}
        className="glass-icon fixed bottom-6 right-6 z-[81] flex h-14 w-14 items-center justify-center
          rounded-full text-neutral-700 dark:text-neutral-200
          transition-all duration-300 hover:scale-110 hover:shadow-xl
          animate-liquid-pop"
      >
        <Pencil className="h-5 w-5" strokeWidth={2.2} />
      </button>
      <button
        onClick={onDelete}
        aria-label={tr('delete')}
        className="fixed bottom-6 left-6 z-[81] flex h-14 w-14 items-center justify-center
          rounded-full bg-gradient-to-br from-rose-400 to-rose-500 text-white
          shadow-lg shadow-rose-500/30
          transition-all duration-300 hover:scale-110 hover:shadow-xl hover:shadow-rose-500/40
          animate-liquid-pop"
      >
        <Trash2 className="h-5 w-5" strokeWidth={2.2} />
      </button>
    </div>
  );
}
