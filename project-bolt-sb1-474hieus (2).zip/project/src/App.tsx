import { useEffect, useState, useCallback } from 'react';
import { AuthProvider, useAuth } from '@/contexts/AuthContext';
import { PrefsProvider, usePrefs } from '@/contexts/PrefsContext';
import { ToastProvider, useToast } from '@/components/Toast';
import { AuthScreen } from '@/components/AuthScreen';
import { Navigation, type NavView } from '@/components/Navigation';
import { MemoryGallery } from '@/components/MemoryGallery';
import { MemoryDetail } from '@/components/MemoryDetail';
import { MemoryForm } from '@/components/MemoryForm';
import { Settings } from '@/components/Settings';
import { ConfirmDialog } from '@/components/ConfirmDialog';
import { FullScreenSpinner } from '@/components/Spinner';
import { supabase, STORAGE_BUCKET } from '@/lib/supabase';
import { initTelegram } from '@/lib/telegram';
import { t } from '@/lib/translations';
import type { Memory } from '@/types';

function AppContent() {
  const { session, loading, accountExists, lock } = useAuth();
  const { language } = usePrefs();
  const { show } = useToast();
  const tr = (key: Parameters<typeof t>[1]) => t(language, key);

  const [view, setView] = useState<NavView>('gallery');
  const [selectedMemory, setSelectedMemory] = useState<Memory | null>(null);
  const [selectedPhotoUrl, setSelectedPhotoUrl] = useState('');
  const [showMemoryForm, setShowMemoryForm] = useState(false);
  const [editingMemory, setEditingMemory] = useState<Memory | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<Memory | null>(null);
  const [deleteLoading, setDeleteLoading] = useState(false);
  const [refreshKey, setRefreshKey] = useState(0);

  useEffect(() => {
    initTelegram();
  }, []);

  const handleNavigate = useCallback((v: NavView) => {
    if (v === 'add') {
      setEditingMemory(null);
      setShowMemoryForm(true);
    } else {
      setView(v);
    }
  }, []);

  const handleMemoryClick = useCallback((memory: Memory, photoUrl: string) => {
    setSelectedMemory(memory);
    setSelectedPhotoUrl(photoUrl);
  }, []);

  const handleCloseDetail = useCallback(() => {
    setSelectedMemory(null);
    setSelectedPhotoUrl('');
  }, []);

  const handleEditFromDetail = useCallback(() => {
    setEditingMemory(selectedMemory);
    setSelectedMemory(null);
    setSelectedPhotoUrl('');
    setShowMemoryForm(true);
  }, [selectedMemory]);

  const handleDeleteFromDetail = useCallback(() => {
    if (selectedMemory) {
      setDeleteTarget(selectedMemory);
      setSelectedMemory(null);
    }
  }, [selectedMemory]);

  const handleFormClose = useCallback(() => {
    setShowMemoryForm(false);
    setEditingMemory(null);
  }, []);

  const handleFormSaved = useCallback(() => {
    setShowMemoryForm(false);
    setEditingMemory(null);
    setRefreshKey((k) => k + 1);
    setView('gallery');
  }, []);

  const handleDeleteConfirm = useCallback(async () => {
    if (!deleteTarget) return;

    setDeleteLoading(true);
    try {
      // Delete photo from storage
      await supabase.storage.from(STORAGE_BUCKET).remove([deleteTarget.photo_path]);

      // Delete memory record
      const { error } = await supabase
        .from('memories')
        .delete()
        .eq('id', deleteTarget.id);

      if (error) throw error;

      show(tr('memoryDeleted'), 'success');
      setRefreshKey((k) => k + 1);
    } catch {
      show(tr('deleteError'), 'error');
    } finally {
      setDeleteLoading(false);
      setDeleteTarget(null);
    }
  }, [deleteTarget, show, tr]);

  const handleDeleteCancel = useCallback(() => {
    setDeleteTarget(null);
  }, []);

  // Loading state
  if (loading) {
    return <FullScreenSpinner label={tr('loading')} />;
  }

  // Not authenticated
  if (!session) {
    if (accountExists === null) {
      return <FullScreenSpinner label={tr('loading')} />;
    }
    return <AuthScreen defaultMode={accountExists ? 'login' : 'signup'} />;
  }

  // Authenticated
  return (
    <div className="min-h-screen bg-neutral-50 dark:bg-neutral-900 transition-colors">
      <Navigation current={view} onNavigate={handleNavigate} />

      <main className="px-4 md:px-8 py-5 pb-36 md:pb-12 max-w-7xl mx-auto">
        {view === 'gallery' && (
          <MemoryGallery
            onMemoryClick={handleMemoryClick}
            onAddClick={() => handleNavigate('add')}
            refreshKey={refreshKey}
          />
        )}
        {view === 'settings' && <Settings onLock={lock} />}
      </main>

      {/* Memory Detail Modal */}
      {selectedMemory && (
        <MemoryDetail
          memory={selectedMemory}
          photoUrl={selectedPhotoUrl}
          onClose={handleCloseDetail}
          onEdit={handleEditFromDetail}
          onDelete={handleDeleteFromDetail}
        />
      )}

      {/* Memory Form Modal */}
      <MemoryForm
        open={showMemoryForm}
        editingMemory={editingMemory}
        existingPhotoUrl={
          editingMemory
            ? supabase.storage.from(STORAGE_BUCKET).getPublicUrl(editingMemory.photo_path).data.publicUrl
            : undefined
        }
        onClose={handleFormClose}
        onSaved={handleFormSaved}
      />

      {/* Delete Confirmation */}
      <ConfirmDialog
        open={!!deleteTarget}
        title={tr('delete')}
        message={tr('deleteConfirm')}
        confirmText={tr('delete')}
        cancelText={tr('cancel')}
        onConfirm={handleDeleteConfirm}
        onCancel={handleDeleteCancel}
        loading={deleteLoading}
      />
    </div>
  );
}

function App() {
  return (
    <AuthProvider>
      <ToastProvider>
        <PrefsProvider>
          <AppContent />
        </PrefsProvider>
      </ToastProvider>
    </AuthProvider>
  );
}

export default App;
