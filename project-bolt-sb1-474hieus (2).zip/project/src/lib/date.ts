import type { Language } from '@/types';

const FALLBACK = '—';

function safeDate(dateStr: string | null | undefined): Date | null {
  if (!dateStr || typeof dateStr !== 'string') return null;
  const padded = dateStr.length === 10 ? dateStr + 'T00:00:00' : dateStr;
  const d = new Date(padded);
  if (isNaN(d.getTime())) return null;
  return d;
}

export function formatDate(dateStr: string | null | undefined, lang: Language): string {
  const date = safeDate(dateStr);
  if (!date) return FALLBACK;

  try {
    if (lang === 'fa') {
      const { jy, jm, jd } = toJalali(date.getFullYear(), date.getMonth() + 1, date.getDate());
      return `${toPersianDigits(jd)} ${JALALI_MONTHS[jm - 1]} ${toPersianDigits(jy)}`;
    }
    return new Intl.DateTimeFormat('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
    }).format(date);
  } catch {
    return FALLBACK;
  }
}

export function formatDateShort(dateStr: string | null | undefined, lang: Language): string {
  const date = safeDate(dateStr);
  if (!date) return FALLBACK;

  try {
    if (lang === 'fa') {
      const { jy, jm, jd } = toJalali(date.getFullYear(), date.getMonth() + 1, date.getDate());
      return `${toPersianDigits(jd)} ${JALALI_MONTHS[jm - 1]} ${toPersianDigits(jy)}`;
    }
    return new Intl.DateTimeFormat('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
    }).format(date);
  } catch {
    return FALLBACK;
  }
}

export function todayISO(): string {
  const now = new Date();
  const tz = now.getTimezoneOffset() * 60000;
  return new Date(now.getTime() - tz).toISOString().slice(0, 10);
}

// ============================================================
// Jalali (Persian Solar) calendar utilities
// ============================================================

export const JALALI_MONTHS = [
  'فروردین', 'اردیبهشت', 'خرداد', 'تیر', 'مرداد', 'شهریور',
  'مهر', 'آبان', 'آذر', 'دی', 'بهمن', 'اسفند',
];

export const JALALI_WEEKDAYS_SHORT = ['ش', 'ی', 'د', 'س', 'چ', 'پ', 'ج'];

export const GREGORIAN_MONTHS = [
  'January', 'February', 'March', 'April', 'May', 'June',
  'July', 'August', 'September', 'October', 'November', 'December',
];

export const GREGORIAN_WEEKDAYS_SHORT = ['Su', 'Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa'];

export interface JalaliDate {
  jy: number;
  jm: number;
  jd: number;
}

export function toJalali(gy: number, gm: number, gd: number): JalaliDate {
  const g_d_m = [0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334];
  const gy2 = gm > 2 ? gy + 1 : gy;
  let days = 355666 + 365 * gy + Math.floor((gy2 + 3) / 4) - Math.floor((gy2 + 99) / 100) + Math.floor((gy2 + 399) / 400) + gd + g_d_m[gm - 1];
  let jy = -1595 + 33 * Math.floor(days / 12053);
  days %= 12053;
  jy += 4 * Math.floor(days / 1461);
  days %= 1461;
  if (days > 365) {
    jy += Math.floor((days - 1) / 365);
    days = (days - 1) % 365;
  }
  let jm: number;
  let jd: number;
  if (days < 186) {
    jm = 1 + Math.floor(days / 31);
    jd = 1 + (days % 31);
  } else {
    jm = 7 + Math.floor((days - 186) / 30);
    jd = 1 + ((days - 186) % 30);
  }
  return { jy, jm, jd };
}

export function toGregorian(jy: number, jm: number, jd: number): { gy: number; gm: number; gd: number } {
  let gy: number;
  let days: number;
  if (jy <= 979) {
    gy = 621;
    days = -146097;
  } else {
    jy -= 979;
    gy = 1600;
    days = -36506;
  }
  gy += 33 * Math.floor(jy / 33);
  jy %= 33;
  days += 365 * jy + Math.floor(jy / 4) * 8;
  jy %= 4;
  if (jy > 0) {
    days += Math.floor((jy - 1) * 30 + Math.floor(jy / 4) * 7);
  }
  if (jm < 7) {
    days += (jm - 1) * 31;
  } else {
    days += (jm - 7) * 30 + 186;
  }
  days += jd - 1;
  gy += 400 * Math.floor(days / 146097);
  days %= 146097;
  if (days > 36524) {
    gy += 100 * Math.floor(--days / 36524);
    days %= 36524;
    if (days >= 365) days++;
  }
  gy += 4 * Math.floor(days / 1461);
  days %= 1461;
  if (days > 365) {
    gy += Math.floor((days - 1) / 365);
    days = (days - 1) % 365;
  }
  const sal_a = [0, 31, 29 + (gy % 4 === 0 && (gy % 100 !== 0 || gy % 400 === 0) ? 1 : 0), 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  let gm = 0;
  for (gm = 0; gm < 13 && days >= sal_a[gm]; gm++) {
    days -= sal_a[gm];
  }
  const gd = days + 1;
  return { gy, gm: gm, gd };
}

export function isJalaliLeapYear(jy: number): boolean {
  const breaks = [-61, 9, 38, 199, 426, 686, 756, 818, 1111, 1181, 1210, 1635, 2060, 2097, 2192, 2268, 2324, 2394, 2456, 3178];
  let jp = breaks[0];
  let leap = false;
  for (let i = 1; i <= breaks.length; i++) {
    const jm = breaks[i];
    const jump = jm - jp;
    if (jy < jm) {
      let n = jy - jp;
      if (jump - n < 6) n = n - jump + Math.floor((jump + 4) / 12);
      leap = ((n + 1) % 4) === 0 && (n % 4) !== 0;
      break;
    }
    jp = jm;
  }
  return leap;
}

export function jalaliDaysInMonth(jy: number, jm: number): number {
  if (jm <= 6) return 31;
  if (jm <= 11) return 30;
  return isJalaliLeapYear(jy) ? 30 : 29;
}

export function gregorianDaysInMonth(gy: number, gm: number): number {
  const days = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  if (gm === 2) {
    const isLeap = (gy % 4 === 0 && gy % 100 !== 0) || gy % 400 === 0;
    return isLeap ? 29 : 28;
  }
  return days[gm - 1];
}

export function isoToJalali(iso: string): JalaliDate {
  const d = safeDate(iso);
  if (!d) return { jy: 1403, jm: 1, jd: 1 };
  return toJalali(d.getFullYear(), d.getMonth() + 1, d.getDate());
}

export function jalaliToISO(jy: number, jm: number, jd: number): string {
  const g = toGregorian(jy, jm, jd);
  const mm = String(g.gm).padStart(2, '0');
  const dd = String(g.gd).padStart(2, '0');
  return `${g.gy}-${mm}-${dd}`;
}

export function getJalaliMonthFirstWeekday(jy: number, jm: number): number {
  const iso = jalaliToISO(jy, jm, 1);
  const d = safeDate(iso);
  if (!d) return 0;
  // 0=Saturday in Jalali calendar display
  return d.getDay();
}

export function formatJalaliDisplay(jy: number, jm: number, jd: number): string {
  return `${jy} ${JALALI_MONTHS[jm - 1]} ${jd}`;
}

export function toPersianDigits(n: number | string): string {
  const persian = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
  return String(n).replace(/\d/g, (d) => persian[parseInt(d)]);
}
