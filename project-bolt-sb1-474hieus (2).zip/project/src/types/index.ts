export type Language = 'fa' | 'en';
export type Theme = 'light' | 'dark';
export type SortOrder = 'newest' | 'oldest';

export interface Profile {
  id: string;
  username: string;
  created_at: string;
  updated_at: string;
}

export interface Memory {
  id: string;
  user_id: string;
  title: string;
  description: string | null;
  memory_date: string;
  photo_path: string;
  created_at: string;
  updated_at: string;
}

export interface Settings {
  id: string;
  user_id: string;
  language: Language;
  theme: Theme;
  updated_at: string;
}

export interface MemoryInput {
  title: string;
  description: string | null;
  memory_date: string;
  photo_path: string;
}
