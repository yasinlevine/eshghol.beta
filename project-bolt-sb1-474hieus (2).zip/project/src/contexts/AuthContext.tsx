import { createContext, useContext, useEffect, useState, useCallback, type ReactNode } from 'react';
import { supabase, usernameToEmail } from '@/lib/supabase';
import type { Session, User } from '@supabase/supabase-js';

interface AuthContextValue {
  session: Session | null;
  user: User | null;
  loading: boolean;
  accountExists: boolean | null;
  checkAccountExists: () => Promise<void>;
  signUp: (username: string, password: string) => Promise<{ error: string | null }>;
  signIn: (username: string, password: string) => Promise<{ error: string | null }>;
  signOut: () => Promise<void>;
  lock: () => Promise<void>;
  changePassword: (currentPassword: string, newPassword: string) => Promise<{ error: string | null }>;
}

const AuthContext = createContext<AuthContextValue | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [session, setSession] = useState<Session | null>(null);
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const [accountExists, setAccountExists] = useState<boolean | null>(null);

  const checkAccountExists = useCallback(async () => {
    try {
      const { data, error } = await supabase.rpc('account_exists');
      if (error) throw error;
      setAccountExists(data as boolean);
    } catch {
      setAccountExists(false);
    }
  }, []);

  useEffect(() => {
    let mounted = true;

    supabase.auth.getSession().then(({ data: { session: s } }) => {
      if (!mounted) return;
      setSession(s);
      setUser(s?.user ?? null);
      setLoading(false);
    });

    const { data: authListener } = supabase.auth.onAuthStateChange((_event, s) => {
      (async () => {
        setSession(s);
        setUser(s?.user ?? null);
        if (!s) {
          await checkAccountExists();
        }
      })();
    });

    checkAccountExists();

    return () => {
      mounted = false;
      authListener.subscription.unsubscribe();
    };
  }, [checkAccountExists]);

  const signUp = useCallback(async (username: string, password: string) => {
    const email = usernameToEmail(username);
    const { error } = await supabase.auth.signUp({
      email,
      password,
      options: { data: { username } },
    });
    if (error) {
      return { error: error.message };
    }
    await checkAccountExists();
    return { error: null };
  }, [checkAccountExists]);

  const signIn = useCallback(async (username: string, password: string) => {
    const email = usernameToEmail(username);
    const { error } = await supabase.auth.signInWithPassword({ email, password });
    if (error) {
      return { error: error.message };
    }
    return { error: null };
  }, []);

  const signOut = useCallback(async () => {
    await supabase.auth.signOut();
  }, []);

  const lock = useCallback(async () => {
    await supabase.auth.signOut();
  }, []);

  const changePassword = useCallback(async (currentPassword: string, newPassword: string) => {
    const email = user?.email;
    if (!email) return { error: 'No user' };

    const { error: signInError } = await supabase.auth.signInWithPassword({
      email,
      password: currentPassword,
    });
    if (signInError) {
      return { error: 'current_password_wrong' };
    }

    const { error: updateError } = await supabase.auth.updateUser({
      password: newPassword,
    });
    if (updateError) {
      return { error: updateError.message };
    }

    return { error: null };
  }, [user]);

  const value: AuthContextValue = {
    session,
    user,
    loading,
    accountExists,
    checkAccountExists,
    signUp,
    signIn,
    signOut,
    lock,
    changePassword,
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used within AuthProvider');
  return ctx;
}
