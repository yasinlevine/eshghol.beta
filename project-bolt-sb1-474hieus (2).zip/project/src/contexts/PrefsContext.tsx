import { createContext, useContext, useEffect, useState, useCallback, type ReactNode } from 'react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/contexts/AuthContext';
import type { Language, Theme } from '@/types';

interface PrefsContextValue {
  language: Language;
  theme: Theme;
  setLanguage: (lang: Language) => void;
  setTheme: (theme: Theme) => void;
  loading: boolean;
}

const PrefsContext = createContext<PrefsContextValue | undefined>(undefined);

export function PrefsProvider({ children }: { children: ReactNode }) {
  const { user } = useAuth();
  const [language, setLanguageState] = useState<Language>('fa');
  const [theme, setThemeState] = useState<Theme>('light');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const savedLang = localStorage.getItem('eshgholk_lang') as Language | null;
    const savedTheme = localStorage.getItem('eshgholk_theme') as Theme | null;
    if (savedLang) setLanguageState(savedLang);
    if (savedTheme) setThemeState(savedTheme);
  }, []);

  useEffect(() => {
    document.documentElement.dir = language === 'fa' ? 'rtl' : 'ltr';
    document.documentElement.lang = language;
    localStorage.setItem('eshgholk_lang', language);
  }, [language]);

  useEffect(() => {
    const root = document.documentElement;
    if (theme === 'dark') {
      root.classList.add('dark');
    } else {
      root.classList.remove('dark');
    }
    localStorage.setItem('eshgholk_theme', theme);
  }, [theme]);

  useEffect(() => {
    if (!user) {
      setLoading(false);
      return;
    }

    let cancelled = false;

    (async () => {
      try {
        const { data, error } = await supabase
          .from('settings')
          .select('language, theme')
          .eq('user_id', user.id)
          .maybeSingle();

        if (cancelled) return;

        if (error) {
          console.warn('Settings load error:', error.message);
        } else if (data) {
          setLanguageState(data.language);
          setThemeState(data.theme);
        }
      } catch (err) {
        console.warn('Settings load failed:', err);
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();

    return () => { cancelled = true; };
  }, [user]);

  const setLanguage = useCallback((lang: Language) => {
    setLanguageState(lang);
    if (user) {
      supabase
        .from('settings')
        .upsert({ user_id: user.id, language: lang, theme }, { onConflict: 'user_id' })
        .then(({ error }) => {
          if (error) console.warn('Settings save error:', error.message);
        });
    }
  }, [user, theme]);

  const setTheme = useCallback((t: Theme) => {
    setThemeState(t);
    if (user) {
      supabase
        .from('settings')
        .upsert({ user_id: user.id, language, theme: t }, { onConflict: 'user_id' })
        .then(({ error }) => {
          if (error) console.warn('Settings save error:', error.message);
        });
    }
  }, [user, language]);

  return (
    <PrefsContext.Provider value={{ language, theme, setLanguage, setTheme, loading }}>
      {children}
    </PrefsContext.Provider>
  );
}

export function usePrefs() {
  const ctx = useContext(PrefsContext);
  if (!ctx) throw new Error('usePrefs must be used within PrefsProvider');
  return ctx;
}
