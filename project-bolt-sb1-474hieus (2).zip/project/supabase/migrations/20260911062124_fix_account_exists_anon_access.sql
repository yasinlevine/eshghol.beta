/*
# Fix: re-grant anon access to account_exists function

## Summary
The previous migration revoked EXECUTE on `account_exists()` from the `anon` role.
However, this function is required BEFORE authentication — the app calls it to
determine whether to show the setup screen (no accounts exist) or the login
screen (accounts exist). Without anon access, the pre-auth flow breaks.

## Changes
- Re-grant EXECUTE on `public.account_exists()` to `anon` role only.
- `authenticated` does NOT need this function (already signed in).
- The function remains SECURITY DEFINER because it must bypass RLS on the
  `profiles` table to check if ANY row exists (anon has no SELECT on profiles).
- The function only returns a boolean — it does NOT expose any user data,
  making it safe for public access.

## Security Impact
- `anon` can call `account_exists()` which returns true/false — no data leakage.
- `authenticated` cannot call it (not needed post-auth).
- All table CRUD privileges remain revoked from `anon`.
*/

GRANT EXECUTE ON FUNCTION public.account_exists() TO anon;