/*
# Add unique constraint on settings.user_id

## Problem
The `settings` table was missing a UNIQUE constraint on `user_id`.
The frontend uses `.upsert({ user_id, language, theme }, { onConflict: 'user_id' })`
which requires a unique constraint on the conflict target column to work correctly.
Without it, upserts create duplicate rows instead of updating existing ones.

## Changes
- Add UNIQUE constraint on `settings.user_id`.
*/

-- Clean up any duplicate rows before adding the constraint
DELETE FROM public.settings
WHERE id NOT IN (
  SELECT (array_agg(id ORDER BY updated_at))[1] FROM public.settings GROUP BY user_id
);

-- Add unique constraint on user_id
CREATE UNIQUE INDEX IF NOT EXISTS settings_user_id_unique ON public.settings (user_id);
