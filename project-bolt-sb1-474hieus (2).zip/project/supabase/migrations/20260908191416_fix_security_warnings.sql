/*
# Fix security advisor warnings

## Changes
1. Set search_path on `update_updated_at()` to fix the mutable search_path warning.
2. Revoke EXECUTE on `handle_new_user()` from anon and authenticated — it's a trigger function that should only fire via the auth.users INSERT trigger, not be called directly via the REST API.
3. `account_exists()` remains callable by anon — it's intentionally public and only returns a boolean (no user data exposed).
*/

-- Fix update_updated_at search_path
CREATE OR REPLACE FUNCTION public.update_updated_at()
RETURNS TRIGGER
LANGUAGE plpgsql
SET search_path = public
AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$;

-- Revoke direct execution of handle_new_user from anon and authenticated
REVOKE EXECUTE ON FUNCTION public.handle_new_user() FROM anon, authenticated;
