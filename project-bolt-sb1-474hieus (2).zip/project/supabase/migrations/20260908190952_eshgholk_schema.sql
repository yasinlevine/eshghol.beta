/*
# Eshgholk - Complete Database Schema

## Overview
Creates the full schema for Eshgholk (عشقولک), a private shared digital memory album for two people.
Uses Supabase built-in auth with a single shared account. The "username" in the UI maps to an
internal email (username@eshgholk.app) so we get secure bcrypt password hashing and session
management from Supabase's backend without any custom crypto.

## New Tables

### profiles
- `id` (uuid, PK, references auth.users) — the auth user's id
- `username` (text, unique, not null) — the shared username
- `created_at` (timestamptz)
- `updated_at` (timestamptz)

### memories
- `id` (uuid, PK)
- `user_id` (uuid, not null, defaults to auth.uid(), references auth.users ON DELETE CASCADE)
- `title` (text, not null)
- `description` (text, nullable, CHECK char_length <= 500)
- `memory_date` (date, not null)
- `photo_path` (text, not null) — path in the memories storage bucket
- `created_at` (timestamptz)
- `updated_at` (timestamptz)

### settings
- `id` (uuid, PK)
- `user_id` (uuid, not null, defaults to auth.uid(), references auth.users ON DELETE CASCADE, UNIQUE)
- `language` (text, not null, default 'fa')
- `theme` (text, not null, default 'light')
- `updated_at` (timestamptz)

## Security
- RLS enabled on all three tables.
- profiles: authenticated owner-only CRUD. Anon cannot read profiles directly.
- memories: authenticated owner-only CRUD (4 separate policies).
- settings: authenticated owner-only CRUD (4 separate policies).
- account_exists() function: SECURITY DEFINER, callable by anon, returns boolean — used for the first-run check without exposing any user data.
- handle_new_user() trigger: SECURITY DEFINER, auto-creates profile + settings rows when a new auth user signs up. Reads username from raw_user_meta_data.
- update_updated_at() trigger: keeps updated_at columns current.

## Storage
- Creates a public bucket "memories" for photo uploads (10MB limit, jpg/png/webp only).
- Storage policies: public read, authenticated write/update/delete.

## Important Notes
1. The frontend converts the username to "username@eshgholk.app" for Supabase auth calls.
2. Password hashing is handled by Supabase's built-in bcrypt — no plaintext passwords anywhere.
3. Both people share one account, so they share one set of memories and settings.
4. The account_exists() function is the only anon-accessible endpoint — it returns just a boolean.
*/

-- ============================================================
-- 1. PROFILES TABLE
-- ============================================================
CREATE TABLE IF NOT EXISTS public.profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  username text UNIQUE NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "profiles_select_own" ON public.profiles;
CREATE POLICY "profiles_select_own" ON public.profiles FOR SELECT
  TO authenticated USING (auth.uid() = id);

DROP POLICY IF EXISTS "profiles_insert_own" ON public.profiles;
CREATE POLICY "profiles_insert_own" ON public.profiles FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = id);

DROP POLICY IF EXISTS "profiles_update_own" ON public.profiles;
CREATE POLICY "profiles_update_own" ON public.profiles FOR UPDATE
  TO authenticated USING (auth.uid() = id) WITH CHECK (auth.uid() = id);

-- ============================================================
-- 2. MEMORIES TABLE
-- ============================================================
CREATE TABLE IF NOT EXISTS public.memories (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  title text NOT NULL,
  description text CHECK (char_length(description) <= 500),
  memory_date date NOT NULL,
  photo_path text NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE public.memories ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "memories_select_own" ON public.memories;
CREATE POLICY "memories_select_own" ON public.memories FOR SELECT
  TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "memories_insert_own" ON public.memories;
CREATE POLICY "memories_insert_own" ON public.memories FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "memories_update_own" ON public.memories;
CREATE POLICY "memories_update_own" ON public.memories FOR UPDATE
  TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "memories_delete_own" ON public.memories;
CREATE POLICY "memories_delete_own" ON public.memories FOR DELETE
  TO authenticated USING (auth.uid() = user_id);

CREATE INDEX IF NOT EXISTS idx_memories_user_id ON public.memories(user_id);
CREATE INDEX IF NOT EXISTS idx_memories_memory_date ON public.memories(memory_date);
CREATE INDEX IF NOT EXISTS idx_memories_created_at ON public.memories(created_at);

-- ============================================================
-- 3. SETTINGS TABLE
-- ============================================================
CREATE TABLE IF NOT EXISTS public.settings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  language text NOT NULL DEFAULT 'fa',
  theme text NOT NULL DEFAULT 'light',
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE public.settings ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "settings_select_own" ON public.settings;
CREATE POLICY "settings_select_own" ON public.settings FOR SELECT
  TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "settings_insert_own" ON public.settings;
CREATE POLICY "settings_insert_own" ON public.settings FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "settings_update_own" ON public.settings;
CREATE POLICY "settings_update_own" ON public.settings FOR UPDATE
  TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "settings_delete_own" ON public.settings;
CREATE POLICY "settings_delete_own" ON public.settings FOR DELETE
  TO authenticated USING (auth.uid() = user_id);

-- ============================================================
-- 4. HELPER FUNCTIONS
-- ============================================================

-- account_exists: callable by anon to check if any account has been set up
CREATE OR REPLACE FUNCTION public.account_exists()
RETURNS boolean
LANGUAGE sql
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS(SELECT 1 FROM public.profiles LIMIT 1);
$$;

GRANT EXECUTE ON FUNCTION public.account_exists() TO anon, authenticated;

-- handle_new_user: trigger to auto-create profile + settings on signup
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  INSERT INTO public.profiles (id, username)
  VALUES (NEW.id, COALESCE(NEW.raw_user_meta_data->>'username', 'user'));

  INSERT INTO public.settings (user_id, language, theme)
  VALUES (NEW.id, 'fa', 'light')
  ON CONFLICT DO NOTHING;

  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- update_updated_at: keeps updated_at current
CREATE OR REPLACE FUNCTION public.update_updated_at()
RETURNS TRIGGER
LANGUAGE plpgsql
AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS profiles_updated_at ON public.profiles;
CREATE TRIGGER profiles_updated_at BEFORE UPDATE ON public.profiles
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at();

DROP TRIGGER IF EXISTS memories_updated_at ON public.memories;
CREATE TRIGGER memories_updated_at BEFORE UPDATE ON public.memories
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at();

DROP TRIGGER IF EXISTS settings_updated_at ON public.settings;
CREATE TRIGGER settings_updated_at BEFORE UPDATE ON public.settings
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at();

-- ============================================================
-- 5. STORAGE BUCKET FOR PHOTOS
-- ============================================================
INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES (
  'memories',
  'memories',
  true,
  10485760,
  ARRAY['image/jpeg', 'image/png', 'image/webp']
)
ON CONFLICT (id) DO NOTHING;

-- Storage policies
DROP POLICY IF EXISTS "memories_storage_read" ON storage.objects;
CREATE POLICY "memories_storage_read" ON storage.objects FOR SELECT
  TO anon, authenticated
  USING (bucket_id = 'memories');

DROP POLICY IF EXISTS "memories_storage_insert" ON storage.objects;
CREATE POLICY "memories_storage_insert" ON storage.objects FOR INSERT
  TO authenticated
  WITH CHECK (bucket_id = 'memories');

DROP POLICY IF EXISTS "memories_storage_update" ON storage.objects;
CREATE POLICY "memories_storage_update" ON storage.objects FOR UPDATE
  TO authenticated
  USING (bucket_id = 'memories') WITH CHECK (bucket_id = 'memories');

DROP POLICY IF EXISTS "memories_storage_delete" ON storage.objects;
CREATE POLICY "memories_storage_delete" ON storage.objects FOR DELETE
  TO authenticated
  USING (bucket_id = 'memories');