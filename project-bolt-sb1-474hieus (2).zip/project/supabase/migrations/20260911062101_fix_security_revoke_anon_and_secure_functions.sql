/*
# Security hardening: revoke anon privileges and secure SECURITY DEFINER function

## Summary
This migration fixes two security issues identified by the database advisor:

1. The `anon` role had full CRUD (SELECT, INSERT, UPDATE, DELETE) privileges on all
   three tables (memories, profiles, settings). Since this app requires authentication,
   the anon role should have NO direct table access — all access goes through
   `authenticated`-only RLS policies with ownership checks.

2. The `account_exists()` function was a SECURITY DEFINER function callable by both
   `anon` and `authenticated` roles. It has been switched to SECURITY INVOKER so it
   runs with the caller's privileges, and EXECUTE has been revoked from `anon` and
   `authenticated` (it is only needed via the RLS policy flow, not direct RPC).

## Changes
### Tables: memories, profiles, settings
- Revoke ALL privileges from `anon` role on all three tables.
- `authenticated` retains its existing CRUD privileges (still gated by RLS policies).

### Function: account_exists()
- Changed from SECURITY DEFINER to SECURITY INVOKER.
- EXECUTE privilege revoked from `anon` and `authenticated`.
- The function is still callable by `postgres` (superuser) for internal use.

## Security Impact
- Unauthenticated requests (using the anon key) can no longer read, insert, update,
  or delete any data in the memories, profiles, or settings tables.
- The `account_exists` RPC endpoint is no longer publicly callable, preventing
  information disclosure about whether accounts exist.
- Authenticated users retain full access to their own data through existing RLS policies.
*/

-- Revoke all privileges from anon on all tables
REVOKE ALL ON public.memories FROM anon;
REVOKE ALL ON public.profiles FROM anon;
REVOKE ALL ON public.settings FROM anon;

-- Secure the account_exists function: switch to SECURITY INVOKER
ALTER FUNCTION public.account_exists() SECURITY INVOKER;

-- Revoke execute from anon and authenticated
REVOKE EXECUTE ON FUNCTION public.account_exists() FROM anon;
REVOKE EXECUTE ON FUNCTION public.account_exists() FROM authenticated;